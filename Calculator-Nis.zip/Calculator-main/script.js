const display = document.querySelector(".display");
const buttons = document.querySelectorAll("button");
const specialChars = ["%", "*", "/", "-", "+", "="];
let output = "";

const calculate = (btnValue) => {
  display.focus();

  if (btnValue === "=" && output !== "") {
    try {
      const result = eval(output.replace("%", "/100"));
      display.value = `${output}=${result}`;
      output = result.toString(); // allow continued operations
    } catch {
      display.value = "Error";
      output = "";
    }
  } else if (btnValue === "AC") {
    output = "";
    display.value = "";
  } else if (btnValue === "DEL") {
    output = output.slice(0, -1);
    display.value = output;
  } else {
    if (output === "" && specialChars.includes(btnValue)) return;
    output += btnValue;
    display.value = output;
  }
};

buttons.forEach((button) => {
  button.addEventListener("click", (e) => calculate(e.target.dataset.value));
});
